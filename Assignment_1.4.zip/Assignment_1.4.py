from typing import List

class User:
    sub: bool

def notify(user: User) -> None:
    pass

#Improving notify_users function

def get_sub_users(users: list[User]) -> list[User]:
    # Filter sub users
    return [user for user in users if user.sub]

def notify_sub_users(users: list[User]) -> None:
    # Notify to a given list of users
    for user in get_sub_users(users):
        notify(user) 



            
